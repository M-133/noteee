import { GraduationCap } from 'lucide-react';

export function Logo() {
  return (
    <div className="rounded-xl border bg-black dark:bg-black border-input p-3 sm:p-4">
      <GraduationCap className="h-8 w-8 sm:h-12 sm:w-12 text-white" />
    </div>
  );
}