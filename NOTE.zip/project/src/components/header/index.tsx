import { Logo } from './logo';
import { ProgressInfo } from './progress-info';
import { ActionButtons } from './action-buttons';

interface HeaderProps {
  completedGoals: number;
  totalGoals: number;
  completedMilestones: number;
  totalMilestones: number;
  isStatsOpen: boolean;
  setIsStatsOpen: (open: boolean) => void;
  isWorkoutOpen: boolean;
  setIsWorkoutOpen: (open: boolean) => void;
  onLogout: () => void;
  onAddGoal: (title: string, description?: string, dueDate?: string, tags?: string[]) => void;
}

export function Header({
  completedGoals,
  totalGoals,
  completedMilestones,
  totalMilestones,
  isStatsOpen,
  setIsStatsOpen,
  isWorkoutOpen,
  setIsWorkoutOpen,
  onLogout,
  onAddGoal,
}: HeaderProps) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-4 sm:gap-6">
        <Logo />
        <ProgressInfo
          completedGoals={completedGoals}
          totalGoals={totalGoals}
          completedMilestones={completedMilestones}
          totalMilestones={totalMilestones}
        />
      </div>
      <ActionButtons
        isStatsOpen={isStatsOpen}
        setIsStatsOpen={setIsStatsOpen}
        isWorkoutOpen={isWorkoutOpen}
        setIsWorkoutOpen={setIsWorkoutOpen}
        onLogout={onLogout}
        onAddGoal={onAddGoal}
      />
    </div>
  );
}