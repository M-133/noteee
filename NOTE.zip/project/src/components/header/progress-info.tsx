import { CheckCircle } from 'lucide-react';

interface ProgressInfoProps {
  completedGoals: number;
  totalGoals: number;
  completedMilestones: number;
  totalMilestones: number;
}

export function ProgressInfo({
  completedGoals,
  totalGoals,
  completedMilestones,
  totalMilestones,
}: ProgressInfoProps) {
  return (
    <div>
      <h1 className="text-2xl font-bold tracking-tight sm:text-3xl md:text-4xl">
        Learning Roadmap
      </h1>
      <div className="mt-1 sm:mt-2 flex items-center gap-1.5 text-sm sm:text-base text-muted-foreground">
        <div className="flex items-center gap-1">
          <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5" />
          <span>
            {completedGoals} of {totalGoals} goals completed
          </span>
        </div>
        <div className="text-white/20 mx-1">•</div>
        <div>
          {completedMilestones} of {totalMilestones} milestones completed
        </div>
      </div>
    </div>
  );
}