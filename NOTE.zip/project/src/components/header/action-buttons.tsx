import { Button } from '@/components/ui/button';
import { BarChart2, Dumbbell } from 'lucide-react';
import { AddGoalDialog } from '@/components/add-goal-dialog';
import { SettingsMenu } from '@/components/settings-menu';
import {
  Collapsible,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

interface ActionButtonsProps {
  isStatsOpen: boolean;
  setIsStatsOpen: (open: boolean) => void;
  isWorkoutOpen: boolean;
  setIsWorkoutOpen: (open: boolean) => void;
  onLogout: () => void;
  onAddGoal: (title: string, description?: string, dueDate?: string, tags?: string[]) => void;
}

export function ActionButtons({
  isStatsOpen,
  setIsStatsOpen,
  isWorkoutOpen,
  setIsWorkoutOpen,
  onLogout,
  onAddGoal,
}: ActionButtonsProps) {
  return (
    <div className="flex items-center gap-2">
      <Collapsible open={isStatsOpen} onOpenChange={setIsStatsOpen}>
        <CollapsibleTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="h-10 w-10 bg-black dark:bg-black border-input"
          >
            <BarChart2 className="h-4 w-4 text-white" />
            <span className="sr-only">Toggle stats</span>
          </Button>
        </CollapsibleTrigger>
      </Collapsible>
      <Collapsible open={isWorkoutOpen} onOpenChange={setIsWorkoutOpen}>
        <CollapsibleTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="h-10 w-10 bg-black dark:bg-black border-input"
          >
            <Dumbbell className="h-4 w-4 text-white" />
            <span className="sr-only">Toggle workout</span>
          </Button>
        </CollapsibleTrigger>
      </Collapsible>
      <SettingsMenu onLogout={onLogout} />
      <AddGoalDialog onAddGoal={onAddGoal} />
    </div>
  );
}