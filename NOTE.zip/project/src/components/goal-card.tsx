import { Goal } from '@/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Trash2, Plus, Clock, Calendar, AlertTriangle } from 'lucide-react';
import { useState } from 'react';
import { formatDistanceToNow, format, isPast, isToday } from 'date-fns';
import { ar } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { EditGoalDialog } from './edit-goal-dialog';

interface GoalCardProps {
  goal: Goal;
  onAddMilestone: (goalId: string, title: string) => void;
  onToggleMilestone: (goalId: string, milestoneId: string) => void;
  onToggleGoal: (goalId: string) => void;
  onDeleteGoal: (goalId: string) => void;
  onDeleteMilestone: (goalId: string, milestoneId: string) => void;
  onEditGoal: (goalId: string, title: string, description?: string, dueDate?: string, tags?: string[]) => void;
}

export function GoalCard({
  goal,
  onAddMilestone,
  onToggleMilestone,
  onToggleGoal,
  onDeleteGoal,
  onDeleteMilestone,
  onEditGoal,
}: GoalCardProps) {
  const [newMilestone, setNewMilestone] = useState('');

  const handleAddMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMilestone.trim()) {
      onAddMilestone(goal.id, newMilestone);
      setNewMilestone('');
    }
  };

  const progress = goal.milestones.length
    ? Math.round(
        (goal.milestones.filter((m) => m.completed).length /
          goal.milestones.length) *
          100
      )
    : 0;

  const completedMilestones = goal.milestones.filter((m) => m.completed).length;
  const totalMilestones = goal.milestones.length;

  const isDueSoon = goal.dueDate && !goal.completed && isPast(new Date(goal.dueDate));
  const isDueToday = goal.dueDate && isToday(new Date(goal.dueDate));

  return (
    <Card className={cn(
      "w-full transition-all duration-200",
      isDueSoon && "border-destructive/50",
      isDueToday && "border-yellow-500/50"
    )}>
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <Checkbox
              checked={goal.completed}
              onCheckedChange={() => onToggleGoal(goal.id)}
              className="h-5 w-5"
            />
            <CardTitle
              className={cn(
                'transition-all duration-200',
                goal.completed && 'line-through opacity-50'
              )}
            >
              {goal.title}
            </CardTitle>
          </div>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span>Created {formatDistanceToNow(new Date(goal.createdAt))} ago</span>
            {goal.dueDate && (
              <>
                <span>•</span>
                <div className="flex items-center space-x-1">
                  <Calendar className="h-3 w-3" />
                  <span className={cn(
                    isDueSoon && "text-destructive font-medium",
                    isDueToday && "text-yellow-600 font-medium"
                  )}>
                    Due {format(new Date(goal.dueDate), "MMM d", { locale: ar })}
                  </span>
                  {isDueSoon && <AlertTriangle className="h-3 w-3 text-destructive" />}
                </div>
              </>
            )}
          </div>
        </div>
        <div className="flex space-x-1">
          <EditGoalDialog goal={goal} onEditGoal={onEditGoal} />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDeleteGoal(goal.id)}
            className="h-8 w-8 text-muted-foreground hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      {goal.description && (
        <CardContent className="pb-2 pt-0 text-sm text-muted-foreground">
          {goal.description}
        </CardContent>
      )}
      
      {goal.tags && goal.tags.length > 0 && (
        <CardContent className="pb-2 pt-0">
          <div className="flex flex-wrap gap-1">
            {goal.tags.map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        </CardContent>
      )}
      
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">
              {completedMilestones} of {totalMilestones} completed
            </span>
            <span className="font-medium">{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
        <form onSubmit={handleAddMilestone} className="flex space-x-2">
          <Input
            placeholder="Add a milestone..."
            value={newMilestone}
            onChange={(e) => setNewMilestone(e.target.value)}
            className="flex-1"
          />
          <Button
            type="submit"
            size="icon"
            disabled={!newMilestone.trim()}
            className="shrink-0"
          >
            <Plus className="h-4 w-4" />
          </Button>
        </form>
        <ScrollArea className="h-[200px] pr-4">
          <div className="space-y-2">
            {goal.milestones.map((milestone) => (
              <div
                key={milestone.id}
                className="group flex items-center justify-between rounded-lg border bg-card p-2 transition-all duration-200 hover:border-primary/50"
              >
                <div className="flex items-center space-x-2">
                  <Checkbox
                    checked={milestone.completed}
                    onCheckedChange={() =>
                      onToggleMilestone(goal.id, milestone.id)
                    }
                  />
                  <span
                    className={cn(
                      'transition-all duration-200',
                      milestone.completed && 'line-through opacity-50'
                    )}
                  >
                    {milestone.title}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onDeleteMilestone(goal.id, milestone.id)}
                  className="h-6 w-6 opacity-0 transition-opacity group-hover:opacity-100"
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}