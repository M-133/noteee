import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Dumbbell, Plus, Timer, Trash2 } from 'lucide-react';

interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: number;
  weight: number;
}

export function WorkoutSection() {
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [newExercise, setNewExercise] = useState({
    name: '',
    sets: 3,
    reps: 12,
    weight: 0,
  });

  const addExercise = () => {
    if (newExercise.name.trim()) {
      setExercises([
        ...exercises,
        {
          id: crypto.randomUUID(),
          ...newExercise,
        },
      ]);
      setNewExercise({
        name: '',
        sets: 3,
        reps: 12,
        weight: 0,
      });
    }
  };

  const removeExercise = (id: string) => {
    setExercises(exercises.filter((exercise) => exercise.id !== id));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Dumbbell className="h-5 w-5" />
            تمارين اليوم
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="grid gap-4 sm:grid-cols-4">
              <div className="sm:col-span-2">
                <Label htmlFor="exercise">اسم التمرين</Label>
                <Input
                  id="exercise"
                  value={newExercise.name}
                  onChange={(e) =>
                    setNewExercise({ ...newExercise, name: e.target.value })
                  }
                  placeholder="مثال: تمرين الضغط"
                />
              </div>
              <div>
                <Label htmlFor="sets">المجموعات</Label>
                <Input
                  id="sets"
                  type="number"
                  min="1"
                  value={newExercise.sets}
                  onChange={(e) =>
                    setNewExercise({
                      ...newExercise,
                      sets: parseInt(e.target.value) || 0,
                    })
                  }
                />
              </div>
              <div>
                <Label htmlFor="reps">التكرارات</Label>
                <Input
                  id="reps"
                  type="number"
                  min="1"
                  value={newExercise.reps}
                  onChange={(e) =>
                    setNewExercise({
                      ...newExercise,
                      reps: parseInt(e.target.value) || 0,
                    })
                  }
                />
              </div>
            </div>
            <div className="flex justify-end">
              <Button onClick={addExercise} className="gap-2">
                <Plus className="h-4 w-4" />
                إضافة تمرين
              </Button>
            </div>
          </div>

          <div className="mt-6 space-y-4">
            {exercises.map((exercise) => (
              <Card key={exercise.id}>
                <CardContent className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <Dumbbell className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">{exercise.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {exercise.sets} مجموعات × {exercise.reps} تكرار
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <Timer className="h-4 w-4 text-muted-foreground" />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeExercise(exercise.id)}
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}