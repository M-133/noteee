import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Calendar, 
  Clock, 
  Sun, 
  Moon, 
  MapPin, 
  Globe,
  Sunrise,
  Sunset,
  Timer,
  CalendarDays
} from 'lucide-react';
import HijriDate from 'hijri-date';

const hijriMonths = [
  'محرم',
  'صفر',
  'ربيع الأول',
  'ربيع الثاني',
  'جمادى الأولى',
  'جمادى الآخرة',
  'رجب',
  'شعبان',
  'رمضان',
  'شوال',
  'ذو القعدة',
  'ذو الحجة'
];

const weekDays = [
  'الأحد',
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت'
];

const gregorianMonths = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر'
];

export function HijriNav() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showSeconds, setShowSeconds] = useState(false);
  const [timeFormat, setTimeFormat] = useState<'12' | '24'>('24');

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const getHijriDate = (date: Date) => {
    const hijri = new HijriDate();
    hijri.gregorianDate = date;
    
    const arabicDay = hijri.day.toString().replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
    const arabicYear = hijri.year.toString().replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
    
    return {
      day: arabicDay,
      month: hijriMonths[hijri.month - 1],
      year: arabicYear,
      fullDate: `${arabicDay} ${hijriMonths[hijri.month - 1]} ${arabicYear}`
    };
  };

  const getGregorianDate = (date: Date) => {
    const day = date.getDate().toString().replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
    const month = gregorianMonths[date.getMonth()];
    const year = date.getFullYear().toString().replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
    
    return `${day} ${month} ${year}`;
  };

  const getFormattedTime = (date: Date) => {
    let hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    let period = '';

    if (timeFormat === '12') {
      period = hours >= 12 ? 'م' : 'ص';
      hours = hours % 12;
      if (hours === 0) hours = 12;
    }

    const formattedHours = hours.toString().padStart(2, '0');
    const formattedMinutes = minutes.toString().padStart(2, '0');
    const formattedSeconds = seconds.toString().padStart(2, '0');

    let timeString = `${formattedHours}:${formattedMinutes}`;
    if (showSeconds) {
      timeString += `:${formattedSeconds}`;
    }
    if (timeFormat === '12') {
      timeString += ` ${period}`;
    }

    return timeString.replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
  };

  const getCurrentDayName = (date: Date) => {
    return weekDays[date.getDay()];
  };

  const getTimeOfDay = () => {
    const hour = currentTime.getHours();
    return { icon: Sun, text: 'السلام عليكم ورحمة الله وبركاته', color: 'text-foreground' };
  };

  const hijriDate = getHijriDate(currentTime);
  const gregorianDate = getGregorianDate(currentTime);
  const dayName = getCurrentDayName(currentTime);
  const timeOfDay = getTimeOfDay();
  const TimeIcon = timeOfDay.icon;

  return (
    <Card className="bg-card border">
      <CardContent className="p-3 sm:p-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted border">
              <TimeIcon className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="space-y-0.5">
              <p className="text-sm font-medium leading-tight">{hijriDate.fullDate}</p>
              <p className="text-xs text-muted-foreground truncate max-w-[180px] sm:max-w-none">
                {timeOfDay.text}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <div className="text-right space-y-0.5">
              <span className="text-base font-bold font-mono block" dir="rtl">
                {getFormattedTime(currentTime)}
              </span>
              <p className="text-xs text-muted-foreground">
                {dayName}
              </p>
            </div>

            <div className="flex gap-1">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setTimeFormat(timeFormat === '12' ? '24' : '12')}
                className="h-7 w-7"
              >
                <span className="text-xs font-medium">
                  {timeFormat === '12' ? '١٢' : '٢٤'}
                </span>
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setShowSeconds(!showSeconds)}
                className="h-7 w-7"
              >
                <Timer className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}