import { GraduationCap } from 'lucide-react';
import { AddGoalDialog } from '@/components/add-goal-dialog';

interface EmptyGoalsProps {
  hasGoals: boolean;
  onAddGoal: (title: string, description?: string, dueDate?: string, tags?: string[]) => void;
}

export function EmptyGoals({ hasGoals, onAddGoal }: EmptyGoalsProps) {
  return (
    <div className="col-span-full rounded-lg border border-dashed p-6 sm:p-8 text-center">
      <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl border bg-card p-2">
        <GraduationCap className="h-6 w-6 text-primary" />
      </div>
      <h2 className="mb-1 text-xl font-semibold">No goals found</h2>
      <p className="mb-4 text-sm text-muted-foreground">
        {hasGoals
          ? 'Try adjusting your search or filter settings.'
          : 'Create your first learning goal to get started on your journey.'}
      </p>
      <AddGoalDialog onAddGoal={onAddGoal} />
    </div>
  );
}