import { Goal } from '@/types';
import { GoalCard } from '@/components/goal-card';
import { EmptyGoals } from './empty-goals';
import { cn } from '@/lib/utils';
import { HijriNav } from '@/components/hijri-nav';

interface GoalsGridProps {
  goals: Goal[];
  filteredGoals: Goal[];
  onAddGoal: (title: string, description?: string, dueDate?: string, tags?: string[]) => void;
  onAddMilestone: (goalId: string, title: string) => void;
  onToggleMilestone: (goalId: string, milestoneId: string) => void;
  onToggleGoal: (goalId: string) => void;
  onDeleteGoal: (goalId: string) => void;
  onDeleteMilestone: (goalId: string, milestoneId: string) => void;
  onEditGoal: (goalId: string, title: string, description?: string, dueDate?: string, tags?: string[]) => void;
}

export function GoalsGrid({
  goals,
  filteredGoals,
  onAddGoal,
  onAddMilestone,
  onToggleMilestone,
  onToggleGoal,
  onDeleteGoal,
  onDeleteMilestone,
  onEditGoal,
}: GoalsGridProps) {
  return (
    <>
      <HijriNav />
      <div
        className={cn(
          'grid gap-4 sm:gap-6',
          filteredGoals.length > 0 && 'sm:grid-cols-1 lg:grid-cols-2'
        )}
      >
        {filteredGoals.length === 0 ? (
          <EmptyGoals hasGoals={goals.length > 0} onAddGoal={onAddGoal} />
        ) : (
          filteredGoals.map((goal) => (
            <GoalCard
              key={goal.id}
              goal={goal}
              onAddMilestone={onAddMilestone}
              onToggleMilestone={onToggleMilestone}
              onToggleGoal={onToggleGoal}
              onDeleteGoal={onDeleteGoal}
              onDeleteMilestone={onDeleteMilestone}
              onEditGoal={onEditGoal}
            />
          ))
        )}
      </div>
    </>
  );
}