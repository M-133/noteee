import { StatsCard } from '@/components/stats-card';
import { SearchAndFilter } from './search-filter';
import { ContributionsGraph } from './contributions-graph';
import { GoalProgressChart } from './analytics/goal-progress-chart';
import { MilestoneCompletionRate } from './analytics/milestone-completion-rate';
import { RecentActivity } from './analytics/recent-activity';
import { CheckCircle, Clock, BarChart2, Target, Zap } from 'lucide-react';
import {
  Collapsible,
  CollapsibleContent,
} from '@/components/ui/collapsible';
import { Goal } from '@/types';

interface StatsSectionProps {
  goals: Goal[];
  totalGoals: number;
  completedGoals: number;
  totalMilestones: number;
  completedMilestones: number;
  averageCompletion: number;
  search: string;
  setSearch: (search: string) => void;
  filter: 'all' | 'active' | 'completed';
  setFilter: (filter: 'all' | 'active' | 'completed') => void;
}

export function StatsSection({
  goals,
  totalGoals,
  completedGoals,
  totalMilestones,
  completedMilestones,
  averageCompletion,
  search,
  setSearch,
  filter,
  setFilter,
}: StatsSectionProps) {
  const activeGoals = goals.filter(goal => !goal.completed).length;
  const completionRate = totalGoals > 0 ? Math.round((completedGoals / totalGoals) * 100) : 0;
  const milestoneRate = totalMilestones > 0 ? Math.round((completedMilestones / totalMilestones) * 100) : 0;

  // حساب معدل الإنجاز اليومي
  const dailyProgress = goals.reduce((acc, goal) => {
    const totalDays = Math.max(1, Math.floor((Date.now() - new Date(goal.createdAt).getTime()) / (1000 * 60 * 60 * 24)));
    const completedTasks = goal.completed ? 1 : 0 + goal.milestones.filter(m => m.completed).length;
    const totalTasks = 1 + goal.milestones.length;
    return acc + (completedTasks / totalTasks) / totalDays;
  }, 0);

  const averageDailyProgress = Math.round((dailyProgress / Math.max(1, goals.length)) * 100);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <StatsCard
          title="الأهداف النشطة"
          value={`${activeGoals}`}
          description={`من إجمالي ${totalGoals} هدف`}
          icon={Target}
        />
        <StatsCard
          title="الأهداف المكتملة"
          value={`${completionRate}%`}
          description={`${completedGoals} من ${totalGoals} مكتمل`}
          icon={CheckCircle}
        />
        <StatsCard
          title="المراحل المكتملة"
          value={`${milestoneRate}%`}
          description={`${completedMilestones} من ${totalMilestones} مكتمل`}
          icon={Clock}
        />
        <StatsCard
          title="متوسط الإنجاز"
          value={`${averageCompletion}%`}
          description="متوسط إكمال جميع الأهداف"
          icon={BarChart2}
        />
        <StatsCard
          title="معدل التقدم اليومي"
          value={`${averageDailyProgress}%`}
          description="متوسط الإنجاز اليومي"
          icon={Zap}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <div className="rounded-lg border bg-card p-4 md:col-span-2 lg:col-span-4">
          <GoalProgressChart goals={goals} />
        </div>
        <div className="space-y-4 md:col-span-2 lg:col-span-3">
          <MilestoneCompletionRate goals={goals} />
          <RecentActivity goals={goals} />
        </div>
      </div>

      <div className="rounded-lg border bg-card p-4">
        <ContributionsGraph goals={goals} />
      </div>

      <SearchAndFilter
        search={search}
        setSearch={setSearch}
        filter={filter}
        setFilter={setFilter}
      />
    </div>
  );
}