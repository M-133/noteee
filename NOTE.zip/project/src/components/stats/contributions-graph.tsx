import { useMemo } from 'react';
import { Goal } from '@/types';
import { format, eachDayOfInterval, subDays, isSameDay } from 'date-fns';

interface ContributionsGraphProps {
  goals: Goal[];
  days?: number;
}

export function ContributionsGraph({ goals, days = 365 }: ContributionsGraphProps) {
  const contributions = useMemo(() => {
    const today = new Date();
    const startDate = subDays(today, days - 1);
    const dateRange = eachDayOfInterval({ start: startDate, end: today });

    return dateRange.map(date => {
      const dailyGoals = goals.filter(goal => 
        isSameDay(new Date(goal.createdAt), date)
      );

      return {
        date,
        count: dailyGoals.length,
        goals: dailyGoals,
      };
    });
  }, [goals, days]);

  const maxContributions = Math.max(...contributions.map(day => day.count));
  
  const getIntensity = (count: number) => {
    if (count === 0) return 'bg-muted hover:bg-muted/80';
    const intensity = Math.ceil((count / maxContributions) * 4);
    return {
      1: 'bg-primary/25 hover:bg-primary/30',
      2: 'bg-primary/50 hover:bg-primary/55',
      3: 'bg-primary/75 hover:bg-primary/80',
      4: 'bg-primary hover:bg-primary/90',
    }[intensity] || 'bg-primary hover:bg-primary/90';
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium">Contribution Activity</h3>
        <p className="text-sm text-muted-foreground">
          {contributions.reduce((sum, day) => sum + day.count, 0)} goals in the last year
        </p>
      </div>
      <div className="grid grid-cols-[repeat(53,1fr)] gap-1">
        {contributions.map((day, i) => (
          <div
            key={i}
            className={`aspect-square rounded-sm ${getIntensity(day.count)} transition-colors`}
            title={`${format(day.date, 'MMM d, yyyy')}: ${day.count} goals`}
          />
        ))}
      </div>
      <div className="flex items-center justify-end gap-2 text-sm">
        <span className="text-muted-foreground">Less</span>
        <div className="flex gap-1">
          {[0, 1, 2, 3, 4].map((level) => (
            <div
              key={level}
              className={`h-3 w-3 rounded-sm ${getIntensity(level)}`}
            />
          ))}
        </div>
        <span className="text-muted-foreground">More</span>
      </div>
    </div>
  );
}