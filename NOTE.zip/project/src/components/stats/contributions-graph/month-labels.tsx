import { format, eachMonthOfInterval, subDays } from 'date-fns';

interface MonthLabelsProps {
  days: number;
}

export function MonthLabels({ days }: MonthLabelsProps) {
  const today = new Date();
  const startDate = subDays(today, days - 1);
  const months = eachMonthOfInterval({ start: startDate, end: today });

  return (
    <div className="grid grid-cols-[2rem_repeat(53,1fr)] text-xs text-muted-foreground">
      <div />
      {months.map((date, i) => (
        <div key={i} className="text-center">
          {format(date, 'MMM')}
        </div>
      ))}
    </div>
  );
}