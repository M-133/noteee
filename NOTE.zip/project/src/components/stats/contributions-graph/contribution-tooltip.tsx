import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { Goal } from '@/types';

interface ContributionTooltipProps {
  date: Date;
  count: number;
  goals: Goal[];
  children: React.ReactNode;
}

export function ContributionTooltip({ date, count, goals, children }: ContributionTooltipProps) {
  const completedGoals = goals.filter(goal => goal.completed);
  const activeGoals = goals.filter(goal => !goal.completed);
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>{children}</TooltipTrigger>
        <TooltipContent className="max-w-[350px] p-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="font-semibold text-base">
                {format(date, 'EEEE, d MMMM yyyy', { locale: ar })}
              </p>
              <Badge variant="secondary" className="text-xs">
                {count} {count === 1 ? 'هدف' : 'أهداف'}
              </Badge>
            </div>
            
            {completedGoals.length > 0 && (
              <div className="space-y-1">
                <p className="text-sm font-medium text-green-600 dark:text-green-400">
                  ✅ أهداف مكتملة ({completedGoals.length})
                </p>
                <ul className="text-sm space-y-1 max-h-20 overflow-y-auto">
                  {completedGoals.map((goal, i) => (
                    <li key={i} className="truncate text-muted-foreground">
                      • {goal.title}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            {activeGoals.length > 0 && (
              <div className="space-y-1">
                <p className="text-sm font-medium text-blue-600 dark:text-blue-400">
                  🎯 أهداف نشطة ({activeGoals.length})
                </p>
                <ul className="text-sm space-y-1 max-h-20 overflow-y-auto">
                  {activeGoals.map((goal, i) => (
                    <li key={i} className="truncate text-muted-foreground">
                      • {goal.title}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            {goals.length === 0 && (
              <p className="text-sm text-muted-foreground italic">
                لا توجد أهداف في هذا اليوم
              </p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}