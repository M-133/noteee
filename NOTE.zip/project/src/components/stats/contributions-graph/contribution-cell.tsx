interface ContributionCellProps {
  intensity: number;
  className?: string;
  onClick?: () => void;
  isSelected?: boolean;
}

const intensityClasses = {
  0: 'bg-muted hover:bg-muted/80',
  1: 'bg-green-200 hover:bg-green-300 dark:bg-green-900 dark:hover:bg-green-800',
  2: 'bg-green-400 hover:bg-green-500 dark:bg-green-700 dark:hover:bg-green-600',
  3: 'bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-400',
  4: 'bg-green-800 hover:bg-green-900 dark:bg-green-300 dark:hover:bg-green-200',
};

export function ContributionCell({ 
  intensity, 
  className = '', 
  onClick,
  isSelected = false 
}: ContributionCellProps) {
  return (
    <div
      className={`
        aspect-square rounded-sm transition-all duration-200 cursor-pointer
        ${intensityClasses[intensity as keyof typeof intensityClasses]} 
        ${isSelected ? 'ring-2 ring-primary ring-offset-1' : ''}
        ${onClick ? 'hover:scale-110 hover:shadow-sm' : ''}
        ${className}
      `}
      onClick={onClick}
    />
  );
}