import { useMemo, useState } from 'react';
import { Goal } from '@/types';
import { format, eachDayOfInterval, subDays, isSameDay, getDay, startOfWeek, endOfWeek } from 'date-fns';
import { ar } from 'date-fns/locale';
import { MonthLabels } from './month-labels';
import { WeekLabels } from './week-labels';
import { ContributionTooltip } from './contribution-tooltip';
import { ContributionCell } from './contribution-cell';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, TrendingUp, Target, Award } from 'lucide-react';

interface ContributionsGraphProps {
  goals: Goal[];
  days?: number;
}

export function ContributionsGraph({ goals, days = 365 }: ContributionsGraphProps) {
  const [selectedWeek, setSelectedWeek] = useState<Date | null>(null);
  
  const contributions = useMemo(() => {
    const today = new Date();
    const startDate = subDays(today, days - 1);
    const dateRange = eachDayOfInterval({ start: startDate, end: today });

    // Calculate the offset to start from Sunday
    const firstDayOffset = getDay(startDate);
    const offsetDays = Array(firstDayOffset).fill(null);

    const contributionDays = dateRange.map(date => {
      const dailyGoals = goals.filter(goal => 
        isSameDay(new Date(goal.createdAt), date)
      );

      return {
        date,
        count: dailyGoals.length,
        goals: dailyGoals,
      };
    });

    return [...offsetDays, ...contributionDays];
  }, [goals, days]);

  const maxContributions = Math.max(...contributions.filter(Boolean).map(day => day?.count || 0));
  
  const getIntensity = (count: number) => {
    if (count === 0) return 0;
    return Math.min(Math.ceil((count / maxContributions) * 4), 4);
  };

  const totalContributions = contributions.reduce((sum, day) => sum + (day?.count || 0), 0);
  const currentStreak = useMemo(() => {
    let streak = 0;
    const sortedDays = [...contributions].filter(Boolean).reverse();
    
    for (const day of sortedDays) {
      if (day && day.count > 0) {
        streak++;
      } else {
        break;
      }
    }
    return streak;
  }, [contributions]);
  
  const longestStreak = useMemo(() => {
    let maxStreak = 0;
    let currentStreak = 0;
    
    contributions.filter(Boolean).forEach(day => {
      if (day && day.count > 0) {
        currentStreak++;
        maxStreak = Math.max(maxStreak, currentStreak);
      } else {
        currentStreak = 0;
      }
    });
    
    return maxStreak;
  }, [contributions]);
  
  const weeklyStats = useMemo(() => {
    if (!selectedWeek) return null;
    
    const weekStart = startOfWeek(selectedWeek);
    const weekEnd = endOfWeek(selectedWeek);
    const weekDays = contributions.filter(day => 
      day && day.date >= weekStart && day.date <= weekEnd
    );
    
    return {
      totalGoals: weekDays.reduce((sum, day) => sum + (day?.count || 0), 0),
      activeDays: weekDays.filter(day => day && day.count > 0).length,
      goals: weekDays.flatMap(day => day?.goals || [])
    };
  }, [selectedWeek, contributions]);
  
  const weekDays = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold">نشاط الأهداف</h3>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Target className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              {totalContributions} هدف
            </span>
          </div>
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              {currentStreak} يوم متتالي
            </span>
          </div>
        </div>
      </div>
      
      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-muted/50 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-primary">{totalContributions}</div>
          <div className="text-xs text-muted-foreground">إجمالي الأهداف</div>
        </div>
        <div className="bg-muted/50 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-green-600">{currentStreak}</div>
          <div className="text-xs text-muted-foreground">الخط الحالي</div>
        </div>
        <div className="bg-muted/50 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-blue-600">{longestStreak}</div>
          <div className="text-xs text-muted-foreground">أطول خط</div>
        </div>
        <div className="bg-muted/50 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-purple-600">
            {Math.round((totalContributions / days) * 100)}%
          </div>
          <div className="text-xs text-muted-foreground">معدل النشاط</div>
        </div>
      </div>

      <div className="space-y-2">
        <MonthLabels days={days} />
        <WeekLabels labels={weekDays} />
        
        <div className="grid grid-cols-[2rem_repeat(53,1fr)] gap-1">
          <div className="grid grid-rows-7 gap-1 text-xs text-muted-foreground">
            {weekDays.map((day, i) => (
              <div key={i} className="h-full flex items-center justify-end left-0">
                {day}
              </div>
            ))}
          </div>

          <div className="col-span-53 grid grid-cols-[repeat(53,1fr)] gap-1">
            {contributions.map((day, i) => (
              <div key={i} className={`${getDay(day?.date || new Date()) === 0 ? 'col-start-1' : ''}`}>
                {day && (
                  <ContributionTooltip
                    date={day.date}
                    count={day.count}
                    goals={day.goals}
                  >
                    <ContributionCell intensity={getIntensity(day.count)} />
                  </ContributionTooltip>
                )}
                {day && getDay(day.date) === 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute -left-8 top-0 h-full w-6 p-0 opacity-0 hover:opacity-100"
                    onClick={() => setSelectedWeek(selectedWeek?.getTime() === day.date.getTime() ? null : day.date)}
                  >
                    📊
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 text-xs">
          <span className="text-muted-foreground">أقل</span>
          <div className="flex gap-1">
            {[0, 1, 2, 3, 4].map((level) => (
              <ContributionCell key={level} intensity={level} className="h-3 w-3" />
            ))}
          </div>
          <span className="text-muted-foreground">أكثر</span>
        </div>
        
        {/* إحصائيات الأسبوع المحدد */}
        {selectedWeek && weeklyStats && (
          <div className="mt-4 p-4 bg-muted/30 rounded-lg border">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium flex items-center gap-2">
                <Award className="h-4 w-4" />
                إحصائيات الأسبوع
              </h4>
              <Badge variant="outline">
                {format(startOfWeek(selectedWeek), 'dd MMM', { locale: ar })} - {format(endOfWeek(selectedWeek), 'dd MMM', { locale: ar })}
              </Badge>
            </div>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-lg font-semibold text-primary">{weeklyStats.totalGoals}</div>
                <div className="text-xs text-muted-foreground">أهداف</div>
              </div>
              <div>
                <div className="text-lg font-semibold text-green-600">{weeklyStats.activeDays}</div>
                <div className="text-xs text-muted-foreground">أيام نشطة</div>
              </div>
              <div>
                <div className="text-lg font-semibold text-blue-600">
                  {Math.round((weeklyStats.activeDays / 7) * 100)}%
                </div>
                <div className="text-xs text-muted-foreground">معدل النشاط</div>
              </div>
            </div>
            {weeklyStats.goals.length > 0 && (
              <div className="mt-3 pt-3 border-t">
                <p className="text-sm font-medium mb-2">أهداف الأسبوع:</p>
                <div className="flex flex-wrap gap-1">
                  {weeklyStats.goals.slice(0, 5).map((goal, i) => (
                    <Badge key={i} variant="secondary" className="text-xs">
                      {goal.title}
                    </Badge>
                  ))}
                  {weeklyStats.goals.length > 5 && (
                    <Badge variant="outline" className="text-xs">
                      +{weeklyStats.goals.length - 5} أكثر
                    </Badge>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}