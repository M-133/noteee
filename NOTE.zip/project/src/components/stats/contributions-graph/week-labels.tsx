interface WeekLabelsProps {
  labels: string[];
}

export function WeekLabels({ labels }: WeekLabelsProps) {
  return (
    <div className="grid grid-cols-[2rem_repeat(53,1fr)] gap-1">
      <div />
      <div className="col-span-53 grid grid-cols-7 text-xs text-muted-foreground">
        {labels.map((label, i) => (
          <div key={i} className="text-center">
            {label}
          </div>
        ))}
      </div>
    </div>
  );
}