import { useMemo } from 'react';
import { Goal } from '@/types';
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { subDays, format, startOfDay } from 'date-fns';
import { ar } from 'date-fns/locale';

interface GoalProgressChartProps {
  goals: Goal[];
  days?: number;
}

export function GoalProgressChart({ goals, days = 30 }: GoalProgressChartProps) {
  const data = useMemo(() => {
    const today = startOfDay(new Date());
    const dates = Array.from({ length: days }, (_, i) => {
      const date = subDays(today, i);
      
      // حساب الأهداف المكتملة حتى هذا التاريخ
      const goalsUntilDate = goals.filter(goal => 
        new Date(goal.createdAt) <= date
      );
      
      const completedCount = goalsUntilDate.filter(goal => goal.completed).length;
      const totalCount = goalsUntilDate.length;
      
      // حساب المراحل المكتملة
      const milestonesUntilDate = goalsUntilDate.flatMap(goal => goal.milestones)
        .filter(milestone => new Date(milestone.createdAt) <= date);
      
      const completedMilestones = milestonesUntilDate.filter(m => m.completed).length;
      const totalMilestones = milestonesUntilDate.length;

      // حساب النسب المئوية
      const goalCompletionRate = totalCount > 0 
        ? Math.round((completedCount / totalCount) * 100) 
        : 0;
      
      const milestoneCompletionRate = totalMilestones > 0
        ? Math.round((completedMilestones / totalMilestones) * 100)
        : 0;

      return {
        date,
        label: format(date, 'dd MMM', { locale: ar }),
        goalRate: goalCompletionRate,
        milestoneRate: milestoneCompletionRate,
        completedGoals: completedCount,
        totalGoals: totalCount,
        completedMilestones,
        totalMilestones,
      };
    }).reverse();

    return dates;
  }, [goals, days]);

  const axisStyle = {
    stroke: '#888888',
    fontSize: 12,
    tickLine: false,
    axisLine: false,
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm font-medium">تحليل التقدم</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[200px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis
                {...axisStyle}
                dataKey="label"
              />
              <YAxis
                {...axisStyle}
                tickFormatter={(value: number) => `${value}%`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  const data = payload[0].payload;
                  return (
                    <div className="rounded-lg border bg-background p-3 shadow-sm">
                      <p className="mb-2 font-medium">{label}</p>
                      <div className="grid gap-2">
                        <div className="space-y-1">
                          <p className="text-xs text-muted-foreground">
                            إكمال الأهداف
                          </p>
                          <div className="flex justify-between gap-2">
                            <span className="font-medium text-[#0ea5e9]">
                              {data.goalRate}%
                            </span>
                            <span className="text-xs text-muted-foreground">
                              ({data.completedGoals} من {data.totalGoals})
                            </span>
                          </div>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs text-muted-foreground">
                            إكمال المراحل
                          </p>
                          <div className="flex justify-between gap-2">
                            <span className="font-medium text-[#22c55e]">
                              {data.milestoneRate}%
                            </span>
                            <span className="text-xs text-muted-foreground">
                              ({data.completedMilestones} من {data.totalMilestones})
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                }}
              />
              <Line
                name="معدل إكمال الأهداف"
                type="monotone"
                dataKey="goalRate"
                stroke="#0ea5e9"
                strokeWidth={2}
                dot={false}
              />
              <Line
                name="معدل إكمال المراحل"
                type="monotone"
                dataKey="milestoneRate"
                stroke="#22c55e"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}