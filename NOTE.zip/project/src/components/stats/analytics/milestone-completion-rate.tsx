import { useMemo } from 'react';
import { Goal } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

interface MilestoneCompletionRateProps {
  goals: Goal[];
}

export function MilestoneCompletionRate({ goals }: MilestoneCompletionRateProps) {
  const stats = useMemo(() => {
    const allMilestones = goals.flatMap(goal => goal.milestones);
    const completed = allMilestones.filter(m => m.completed).length;
    const total = allMilestones.length;
    const rate = total > 0 ? Math.round((completed / total) * 100) : 0;

    // تحليل تفصيلي للأهداف
    const byGoal = goals
      .map(goal => {
        const completedMilestones = goal.milestones.filter(m => m.completed).length;
        const totalMilestones = goal.milestones.length;
        return {
          id: goal.id,
          title: goal.title,
          completed: completedMilestones,
          total: totalMilestones,
          rate: totalMilestones > 0 ? Math.round((completedMilestones / totalMilestones) * 100) : 0,
          lastUpdated: goal.milestones.reduce((latest, m) => {
            const date = new Date(m.createdAt);
            return latest > date ? latest : date;
          }, new Date(0))
        };
      })
      .filter(g => g.total > 0)
      .sort((a, b) => b.rate - a.rate || b.lastUpdated.getTime() - a.lastUpdated.getTime());

    // حساب معدل الإنجاز اليومي
    const dailyAverage = total > 0 
      ? Math.round((completed / total) * 100 / (goals.length || 1))
      : 0;

    return {
      completionRate: rate,
      totalMilestones: total,
      completedMilestones: completed,
      dailyAverage,
      byGoal: byGoal.slice(0, 5) // أفضل 5 أهداف
    };
  }, [goals]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm font-medium">تحليل إنجاز المراحل</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">
              {stats.completedMilestones} من {stats.totalMilestones} مكتمل
            </span>
            <span className="text-sm font-medium">{stats.completionRate}%</span>
          </div>
          <Progress value={stats.completionRate} className="h-2" />
          <p className="text-xs text-muted-foreground mt-1">
            معدل الإنجاز اليومي: {stats.dailyAverage}%
          </p>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium">أفضل الأهداف أداءً</h4>
            <span className="text-xs text-muted-foreground">نسبة الإكمال</span>
          </div>
          {stats.byGoal.map((goal, i) => (
            <div key={goal.id} className="space-y-2">
              <div className="flex items-center justify-between text-sm gap-2">
                <div className="flex-1 min-w-0">
                  <p className="truncate text-muted-foreground">
                    {goal.title}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    آخر تحديث: {format(goal.lastUpdated, 'dd MMM yyyy', { locale: ar })}
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs text-muted-foreground">
                    {goal.completed}/{goal.total}
                  </span>
                  <span className="font-medium w-12 text-right">
                    {goal.rate}%
                  </span>
                </div>
              </div>
              <Progress value={goal.rate} className="h-1" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}