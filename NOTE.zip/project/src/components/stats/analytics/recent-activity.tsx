import { Goal } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';
import { CheckCircle2, Circle, Target } from 'lucide-react';

interface RecentActivityProps {
  goals: Goal[];
  limit?: number;
}

export function RecentActivity({ goals, limit = 5 }: RecentActivityProps) {
  const sortedGoals = [...goals]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm font-medium">النشاط الأخير</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px] pr-4">
          <div className="space-y-4">
            {sortedGoals.map((goal) => (
              <div key={goal.id} className="flex items-start gap-4">
                <div className="mt-1">
                  {goal.completed ? (
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                  ) : (
                    <Circle className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium leading-none">{goal.title}</p>
                  <p className="text-sm text-muted-foreground">
                    {formatDistanceToNow(new Date(goal.createdAt), {
                      addSuffix: true,
                      locale: ar,
                    })}
                  </p>
                  {goal.milestones.length > 0 && (
                    <div className="mt-2 text-xs text-muted-foreground">
                      <Target className="mr-1 inline-block h-3 w-3" />
                      {goal.milestones.filter((m) => m.completed).length} من{' '}
                      {goal.milestones.length} مراحل مكتملة
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}