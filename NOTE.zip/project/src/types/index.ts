export interface Milestone {
  id: string;
  title: string;
  completed: boolean;
  createdAt: string;
  dueDate?: string;
}

export interface Goal {
  id: string;
  title: string;
  description?: string;
  dueDate?: string;
  tags: string[];
  milestones: Milestone[];
  completed: boolean;
  createdAt: string;
}

export interface User {
  email: string;
  password: string;
}