import { useState, useEffect } from 'react';
import { Goal } from '@/types';

export function useGoals() {
  const [goals, setGoals] = useState<Goal[]>(() => {
    const saved = localStorage.getItem('learning-goals');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('learning-goals', JSON.stringify(goals));
  }, [goals]);

  const addGoal = (title: string, description?: string, dueDate?: string, tags: string[] = []) => {
    setGoals((prev) => [
      {
        id: crypto.randomUUID(),
        title,
        description,
        dueDate,
        tags,
        milestones: [],
        completed: false,
        createdAt: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const editGoal = (goalId: string, title: string, description?: string, dueDate?: string, tags: string[] = []) => {
    setGoals((prev) =>
      prev.map((goal) =>
        goal.id === goalId
          ? {
              ...goal,
              title,
              description,
              dueDate,
              tags,
            }
          : goal
      )
    );
  };

  const addMilestone = (goalId: string, title: string, dueDate?: string) => {
    setGoals((prev) =>
      prev.map((goal) =>
        goal.id === goalId
          ? {
              ...goal,
              milestones: [
                ...goal.milestones,
                {
                  id: crypto.randomUUID(),
                  title,
                  dueDate,
                  completed: false,
                  createdAt: new Date().toISOString(),
                },
              ],
            }
          : goal
      )
    );
  };

  const toggleMilestone = (goalId: string, milestoneId: string) => {
    setGoals((prev) =>
      prev.map((goal) =>
        goal.id === goalId
          ? {
              ...goal,
              milestones: goal.milestones.map((milestone) =>
                milestone.id === milestoneId
                  ? { ...milestone, completed: !milestone.completed }
                  : milestone
              ),
            }
          : goal
      )
    );
  };

  const toggleGoal = (goalId: string) => {
    setGoals((prev) =>
      prev.map((goal) =>
        goal.id === goalId ? { ...goal, completed: !goal.completed } : goal
      )
    );
  };

  const deleteGoal = (goalId: string) => {
    setGoals((prev) => prev.filter((goal) => goal.id !== goalId));
  };

  const deleteMilestone = (goalId: string, milestoneId: string) => {
    setGoals((prev) =>
      prev.map((goal) =>
        goal.id === goalId
          ? {
              ...goal,
              milestones: goal.milestones.filter((m) => m.id !== milestoneId),
            }
          : goal
      )
    );
  };

  return {
    goals,
    addGoal,
    editGoal,
    addMilestone,
    toggleMilestone,
    toggleGoal,
    deleteGoal,
    deleteMilestone,
  };
}