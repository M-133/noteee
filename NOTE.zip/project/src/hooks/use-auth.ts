import { useState, useEffect } from 'react';
import { User } from '@/types';

const DEFAULT_USER: User = {
  email: 'admin',
  password: 'admin'
};

export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    const saved = localStorage.getItem('auth');
    return saved ? JSON.parse(saved) : false;
  });

  useEffect(() => {
    localStorage.setItem('auth', JSON.stringify(isAuthenticated));
  }, [isAuthenticated]);

  const login = (email: string, password: string): boolean => {
    if (email === DEFAULT_USER.email && password === DEFAULT_USER.password) {
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
  };

  return { isAuthenticated, login, logout };
}