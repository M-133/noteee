import { Goal } from '@/types';

export function calculateGoalStats(goals: Goal[]) {
  const completedGoals = goals.filter((goal) => goal.completed).length;
  const totalMilestones = goals.reduce(
    (acc, goal) => acc + goal.milestones.length,
    0
  );
  const completedMilestones = goals.reduce(
    (acc, goal) =>
      acc + goal.milestones.filter((milestone) => milestone.completed).length,
    0
  );

  const averageCompletion =
    goals.length > 0
      ? Math.round(
          (goals.reduce(
            (acc, goal) =>
              acc +
              (goal.milestones.length > 0
                ? goal.milestones.filter((m) => m.completed).length /
                  goal.milestones.length
                : 0),
            0
          ) /
            goals.length) *
            100
        )
      : 0;

  return {
    completedGoals,
    totalMilestones,
    completedMilestones,
    averageCompletion,
  };
}

export function filterGoals(
  goals: Goal[],
  filter: 'all' | 'active' | 'completed',
  search: string
) {
  return goals
    .filter((goal) => {
      if (filter === 'active') return !goal.completed;
      if (filter === 'completed') return goal.completed;
      return true;
    })
    .filter(
      (goal) =>
        goal.title.toLowerCase().includes(search.toLowerCase()) ||
        goal.description?.toLowerCase().includes(search.toLowerCase()) ||
        goal.tags?.some(tag => tag.toLowerCase().includes(search.toLowerCase())) ||
        goal.milestones.some((m) =>
          m.title.toLowerCase().includes(search.toLowerCase())
        )
    );
}